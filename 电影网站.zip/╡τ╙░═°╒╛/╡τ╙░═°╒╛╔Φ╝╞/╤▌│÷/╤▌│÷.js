	$(function() {
		//将第一张图复制到最后
		$("#imgDiv img:first").clone().appendTo("#imgDiv");
		//将第一张图的索引改为yellow
		//box-shadow: 0 0 10px #00FFFF;
		$("#showImg ul li:first").css("box-shadow", "0 0 10px yellow")
		var tu = 1; //图片索引
		var time1; //定时器
		moveImg();
		//为图片添加动画
		function moveImg() {
			$("#imgDiv").animate({
				marginLeft: -1100 * tu + "px"
			}, 1500, function() {
				//当动画结束后执行
				if(tu == 4) {
					changeColor(0);
					//将轮播图右边距还原
					$("#imgDiv").css("margin-left", "0px");
					tu = 1;
				} else {
					changeColor(tu);
					tu++;
				}
				time1 = setTimeout(moveImg, 1000);
			})
		}
		//修改索引颜色
		function changeColor(xia) {
			$("#showImg ul li").css("box-shadow", "0 0 10px #00FFFF")
			$("#showImg ul li:eq(" + xia + ")").css("box-shadow", "0 0 10px yellow")
		}

		//鼠标移入停止
		$("#showImg").mouseover(function() {
			$("#imgDiv").stop();
			clearTimeout(time1);
		})
		//鼠标移出开始
		$("#showImg").mouseout(function() {
			moveImg();
		})

		//移入索引，直接到索引相对应的图片
		$("#showImg ul li").mouseover(function() {
			tu = $(this).text();
			$("#imgDiv").css("margin-left", -800 * (tu - 1) + "px");
			changeColor(tu - 1);
		})
	})	