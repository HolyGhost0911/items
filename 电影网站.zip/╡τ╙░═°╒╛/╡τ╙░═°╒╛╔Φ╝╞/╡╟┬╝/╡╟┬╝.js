window.addEventListener('load', function() {

    
    var pwd = document.querySelector(".pwd");
    pwd.onblur = function () {
      if (this.value.length < 6 || this.value.length > 16) {
        alert("输入密码格式有误!");
      } else {
        alert("输入密码格式正确!");
      }
    };

    var text = document.querySelector(".account");
    text.onfocus = function () {
      if (this.value === "请输入账号") {
        this.value = "";
      }
      this.style.color = "black";
    };
    text.onblur = function () {
      if (this.value == "") {
        this.value = "请输入账号";
      }
      this.style.color = "gray";
    };

var btn = document.querySelector('.button');
    btn.onclick = function(){
      location.replace('../网站首页.html')
    }
    console.log(navigator.userAgent);
    
    var box = document.querySelector("main");
    var title = document.querySelector("h3");
    //但鼠标按下  就获得鼠标在盒子内的坐标
    title.addEventListener("mousedown", function (e) {
      var x = e.pageX - box.offsetLeft;
      var y = e.pageY - box.offsetTop;
      //鼠标移动时  将鼠标在页面中的坐标 减去 鼠标在盒子内的坐标  就是拖拽框的left和top值
      document.addEventListener("mousemove", move);
      function move(e) {
        box.style.left = e.pageX - x + "px";
        box.style.top = e.pageY - y + "px";
      }
      document.addEventListener("mouseup", function (e) {
        document.removeEventListener("mousemove", move);
      });
    });
})