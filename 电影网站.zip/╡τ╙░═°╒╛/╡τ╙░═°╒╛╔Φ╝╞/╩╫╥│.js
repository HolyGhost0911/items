window.addEventListener('load', function () {

  //横向动画
  function animate(obj, target, interval, callback) {
    //清除定时器
    clearInterval(obj.timer)
    obj.timer = setInterval(function () {
      //步长
      var step = (target - obj.offsetLeft)
      step = step > 0 ? Math.ceil(step) : Math.floor(step)
      //到目标位置停止
      if (obj.offsetLeft == target) {
        clearInterval(obj.timer)
        callback && callback()
      }
      obj.style.left = obj.offsetLeft + step + "px"
    }, interval)
  }



  var card = document.querySelector(".nav").querySelectorAll("li");
  var items = document.querySelectorAll(".item");

  for (var i = 0; i < card.length - 2; i++) {
    card[i].setAttribute("index", i);
    card[8].removeAttribute('index');

    card[i].onclick = function () {
      for (var i = 0; i < card.length; i++) {
        card[i].style.backgroundColor = "";
      }
      this.style.backgroundColor = "#f0932b";

      card[0].style.backgroundColor = "";
      card[8].style.backgroundColor = "";
      //页面引入
      var index = this.getAttribute("index");
      if (index == 0) {
        window.location.href = "./网站首页.html";
      } else if (index == 1) {
        window.location.href = "./网站首页.html";
      } else if (index == 2) {
        window.location.href = "./电影/电影.html";
      } else if (index == 3) {
        window.location.href = "./影院/影院.html";
      } else if (index == 4) {
        window.location.href = "./演出/演出.html";
      } else if (index == 5) {
        window.location.href = "./榜单/榜单.html";
      } else if (index == 6) {
        window.location.href = "./热点/热点.html";
      } else if (index == 7) {
        window.location.href = "./商城/商城.html";
      }

      for (var i = 0; i < items.length-1; i++) {
        items[i].style.display = "none";
      }
      items[index].style.display = "block";
    };
  }
  //搜索框
  var text = document.querySelector(".text");
  var searchInf = document.querySelector('.search_inf')


  text.onfocus = function () {
    if (this.value === "我和我的祖国") {
      this.value = "";
    }
    this.style.color = "black";
    searchInf.style.display="block"
  };
  text.onblur = function () {
    if (this.value == "") {
      this.value = "我和我的祖国";
    }
    this.style.color = "gray";
    searchInf.style.display="none"
  };


  var logon = document.querySelector(".logon");
  logon.addEventListener("click", function () {
    window.location.href = "./登录/登录.html";
  });

  var btn1 = document.querySelector(".container").querySelector(".left");
  var btn2 = document
    .querySelector(".container")
    .querySelector(".right");
  var focus = document.querySelector(".container");
  var poster = document.querySelector(".poster");
  var photo = document.querySelector(".poster").querySelectorAll("div");
  var point = document.querySelector(".cri").querySelectorAll("li");
  var Beat = document.querySelector(".beat");

  //轮播图箭头显示隐藏
  focus.addEventListener('mouseenter', function () {
    btn1.style.display = 'block';
    btn2.style.display = 'block';
  })
  focus.addEventListener('mouseleave', function () {
    btn1.style.display = 'none';
    btn2.style.display = 'none';
  })


  //轮播图箭头点击事件
  var num = 1;
  var float = 1;
  btn2.addEventListener('click', function () {
    if (num == poster.children.length) {
      poster.style.left = 0;
      num = 0;
    }
    num++;
    animate(poster, -num * 1100 + 1100, 110)

    float++;
    if (float == point.length) {
      float = 1;
    }
    for (var i = 0; i < point.length; i++) {
      Beat.style.display = "none";
      point[i].style.backgroundColor = "#FFF";
      point[i].style.opacity = ".5";
    }
    //point[float].className='beat'
    point[float - 1].style.backgroundColor = "#f0932b";
    point[float - 1].style.opacity = "1";
  })

  btn1.addEventListener('click', function () {

    if (num == 1) {
      poster.style.left = -photo.length * 1100 + 'px';
      num = photo.length + 1;
    }
    num--;
    animate(poster, -num * 1100 + 1100, 110)


    float--;
    if (float <= 0) {
      float = point.length - 1;
    }
    for (var i = 0; i < point.length; i++) {
      Beat.style.display = "none";
      point[i].style.backgroundColor = "#FFF";
      point[i].style.opacity = ".5";
    }
    //point[float].className='beat'
    point[float - 1].style.backgroundColor = "#f0932b";
    point[float - 1].style.opacity = "1";
  })


  //轮播图小圆点 onclick事件
  for (var j = 0; j < point.length; j++) {
    point[j].setAttribute("index1", j);
    point[j].onclick = function () {
      for (var j = 0; j < point.length; j++) {
        Beat.style.display = "none";
        point[j].style.backgroundColor = "#FFF";
        point[j].style.opacity = ".5";
      }
      this.style.backgroundColor = "#f0932b";
      this.style.opacity = "1";

      var index1 = this.getAttribute("index1");

      for (var j = 0; j < photo.length; j++) {
        photo[j].style.display = "none";
      }
      photo[index1].style.display = "block";
      setInterval(function () {
        location.reload();
      }, 4200);
    };
  }


  var bar = document.querySelector(".slider-bar");
  var banner = document.querySelector(".poster");
  var bannerTop = banner.offsetTop;
  var barTop = bar.offsetTop - bannerTop;
  var main = document.querySelector(".popular");
  var goBackTop = document.querySelector(".back-top");
  var goToBottom = document.querySelector('.back-bottom')
  var mainTop = main.offsetTop;
  //一键升天 一键回底
  document.addEventListener("scroll", function () {
    if (window.pageYOffset >= bannerTop) {
      bar.style.position = "fixed";
      bar.style.top = barTop + "px";
    } else {
      bar.style.position = "absolute";
      bar.style.top = "20em";
    }
    if (window.pageYOffset >= mainTop) {
      goBackTop.style.display = "block";
      goToBottom.style.display = "none";
    } else {
      goBackTop.style.display = "none";
      goToBottom.style.display = 'block'
    }
  });
  goBackTop.addEventListener("click", function () {
    if (window.pageYOffset >= mainTop) {
      document.documentElement.scrollTop = 0;
    }
  });
  goToBottom.addEventListener("click", function () {
    if (window.pageYOffset <= mainTop) {

      document.documentElement.scrollTop = 1600;
    }
  });
})