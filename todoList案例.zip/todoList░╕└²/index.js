$(function () {

    load();

    $("#title").on("keydown", function (e) {
        if (e.keyCode == 13) {
            if ($(this).val() === '') {
                alert("请输入内容!");
            } else {

                //读取本地存储原有数据
                var local = getDate();
                //console.log(local);
                //将最新数据追加给local数组
                local.push({
                    title: $(this).val(),
                    done: false
                });
                //将这个数组local 存储给本地存储
                saveData(local);
                //将本地数据渲染到页面中
                load();
                $(this).val("");

            }
        }
    })

    //删除操作
    $("ol,ul").on("click", "a", function () {
        var data = getDate(); //获取本地存储

        //修改数据
        var index = $(this).attr("id");
        data.splice(index, 1);
        //保存到本地存储
        saveData(data);
        //重新渲染页面
        load();
    })

    //正在进行 和  已经完成 模块
    $("ol,ul").on("click", "input", function () {
        //获取本地存储
        var data = getDate();

        //修改数据
        var index = $(this).siblings("a").attr("id"); //点击后  拿到同级元素a 的id号
        data[index].done = $(this).prop("checked") //修改当前索引号的checked属性

        //保存到本地存储
        saveData(data);

        //重新渲染页面
        load();
    })

    //封装一个读取本地存储的数据 的函数
    function getDate() {
        var data = localStorage.getItem("todo-list");
        if (data != null) {
            //本地存储里面的的数据是string类型  但是我们需要的是对象格式
            return JSON.parse(data);
        } else {
            return [];
        }
    }

    //封装一个保存本地存储数据 的函数
    function saveData(data) {
        localStorage.setItem("todo-list", JSON.stringify(data))
    }

    //封装一个渲染加载数据的 函数
    function load() {
        //读取本地存储的数据
        var data = getDate();
        // console.log(data);
        //遍历之前 先清空ol里面的元素内容
        $("ol,ul").empty();


        //统计 正在进行和已经完成 的个数
        var todoCount = 0;
        var doneCount = 0;
        //遍历这个数据
        $.each(data, function (indexInArray, valueOfElement) {

            if (valueOfElement.done == true) {
                $("ul").prepend('<li><input type="checkbox" checked="checked"><p>' + valueOfElement.title + '</p><a href="javascript:;" id=' + indexInArray + '></a></li>');
                doneCount++
            } else {
                $("ol").prepend('<li><input type="checkbox"><p>' + valueOfElement.title + '</p><a href="javascript:;" id=' + indexInArray + '></a></li>');
                todoCount++;
            }
            if ($("ul>li").length == 0) {
                $("#done-count").hide(300)
            } else {
                $("#done-count").show(300)
            }
            if ($("ol>li").length == 0) {
                $("#todo-count").hide(300);
            } else {
                $("#todo-count").show(300)
            }
        });
        $("#todo-count").text(todoCount);
        $("#done-count").text(doneCount);

    }
    console.log($("ul>li").length);

})